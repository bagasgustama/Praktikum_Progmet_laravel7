<!-- footer -->
<div class="footer">
  <div class="container">
    <div class="footer-grids">
      <div class="col-md-9 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
        <h3>About Us</h3>
        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse.<span>Excepteur sint occaecat cupidatat 
          non proident, sunt in culpa qui officia deserunt mollit.</span></p>
      </div>
      <div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
        <h3>Contact Info</h3>
        <ul>
          <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>1234k Avenue, 4th block, <span>New York City.</span></li>
          <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@example.com</a></li>
          <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+1234 567 567</li>
        </ul>
      </div>
      <div class="clearfix"> </div>
    </div>
    {{-- <div class="footer-logo animated wow slideInUp" data-wow-delay=".5s">
      <h2><a href="index.html">Best Store <span>shop anywhere</span></a></h2>
    </div>
    <div class="copy-right animated wow slideInUp" data-wow-delay=".5s">
      <p>&copy 2016 Best Store. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
    </div> --}}
  </div>
</div>