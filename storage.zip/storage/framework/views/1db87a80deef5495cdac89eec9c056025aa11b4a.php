<!-- footer -->
<div class="footer">
  <div class="container">
    <div class="footer-grids">
      <div class="col-md-9 footer-grid animated wow slideInLeft" data-wow-delay=".5s">
        <h3>About Us</h3>
        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse.<span>Excepteur sint occaecat cupidatat 
          non proident, sunt in culpa qui officia deserunt mollit.</span></p>
      </div>
      <div class="col-md-3 footer-grid animated wow slideInLeft" data-wow-delay=".6s">
        <h3>Contact Info</h3>
        <ul>
          <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>1234k Avenue, 4th block, <span>New York City.</span></li>
          <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@example.com</a></li>
          <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+1234 567 567</li>
        </ul>
      </div>
      <div class="clearfix"> </div>
    </div>
    
  </div>
</div><?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_footer.blade.php ENDPATH**/ ?>