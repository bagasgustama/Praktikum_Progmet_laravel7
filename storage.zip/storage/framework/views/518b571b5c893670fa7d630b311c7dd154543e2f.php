<style>.categories{margin-top: 0px !important;}</style>


  <div class="categories animated wow slideInUp" data-wow-delay=".5s">
      <h3>Categories</h3>
      <ul class="cate">
        <?php $__currentLoopData = $data_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listkategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="active">
            <li><a href="/kategori/<?php echo e($listkategori->id); ?>"><?php echo e($listkategori->category_name); ?></a></li>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
  </div>
<?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_sidebar.blade.php ENDPATH**/ ?>