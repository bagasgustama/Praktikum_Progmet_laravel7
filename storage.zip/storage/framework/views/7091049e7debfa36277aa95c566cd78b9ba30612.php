
<?php $__env->startSection('content'); ?>
<!-- breadcrumbs -->
<div class="breadcrumbs">
	<div class="container">
		<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
			<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
			<li class="active">Single Page</li>
		</ol>
	</div>
</div>
<!-- //breadcrumbs -->
<!-- single -->
<div class="single">
	<div class="container">
		
		<div class="col-md-12 single-right">
			<div class="col-md-5 single-right-left animated wow slideInUp" data-wow-delay=".5s">
				<div class="col-sm-4 col-md-5 fix-height">
					<div class="new-collections-grid1-image">
						<a class="product-image"><img src="<?php echo e(asset('images/19.jpg')); ?>" alt=" " class="img-responsive"></a>
						 
							

					</div>

			</div>
				
				<!-- flixslider -->
					
					
				<!-- flixslider -->
			</div>
			<div class="col-md-7 single-right-left simpleCart_shelfItem animated wow slideInRight" data-wow-delay=".5s">
				<h3><?php echo e($produk->product_name); ?></h3>

				<?php $__empty_1 = true; $__currentLoopData = $produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

				<?php if(date('Y-m-d')>= $diskonbarang->start && date('Y-m-d')< $diskonbarang->end): ?>
						<?php
						$nilaidiskon = ($diskonbarang->percentage / 100)* $produk->price
						?>

							<h5 class="mt-4" style="margin-top: 20px;"><i>Rp.<?php echo e(number_format($produk["price"])); ?></i></h5><h5><span class="item_price"> Disc <?php echo e($diskonbarang["percentage"]); ?>%</span></h5>
							<h4><span class="" style="font-weight: bold">Rp.<?php echo e(number_format($produk["price"]-$nilaidiskon)); ?></span></h4>

				<?php else: ?>
						
						<h4><span class="item_price" style="font-weight: bold">Rp.<?php echo e(number_format($produk["price"])); ?></span></h4>

				<?php endif; ?>

		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			 
				<h4><span class="item_price" style="font-weight: bold">Rp.<?php echo e(number_format($produk["price"])); ?></span></h4>

		<?php endif; ?>


				
				<div class="rating1">
					<div class="description">
					<h5 ><i>Rating</i></h5>
					<span class="starRating" style="height: 23px">

						<?php if($produk->reviewproduk->avg('rate')): ?>
        
							<?php for($i = 0; $i < 5; $i++): ?>
									<?php if(floor($produk->reviewproduk->avg('rate')) - $i >= 1): ?>
									
									<img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
											
									<?php elseif($produk->reviewproduk->avg('rate') - $i > 0): ?>
									
									<img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >

											
									<?php else: ?>
									
									<img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >

											
									<?php endif; ?>
							<?php endfor; ?>

						<?php else: ?>
							<?php for($i = 0; $i < 5; $i++): ?>
							<img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >

							<?php endfor; ?>

						<?php endif; ?>
					</span>
				</div>
				</div>
				<div class="description">
					<h5><i>Description</i></h5>
					<p><?php echo e($produk["description"]); ?></p>
				</div>
				<div class="description">
					<h5 class="mt-4"><i>Stok</i></h5>
					<p><?php echo e($produk["stock"]); ?></p>
					<h5 class="mt-4"><i>Weight</i></h5>
					<p><?php echo e($produk["weight"]); ?> gram</p>
				</div>
				
				<div class="occasion-cart">
					<form action="/produk/store/buynow" method="POST">
						<?php echo csrf_field(); ?>
						<input type="hidden" value="<?php echo e($produk->id); ?>" name="id_produk">
						<button class="text-blue" style="width: 150px; padding-right: 41px" type="submit">Buy Now</button>
				</form>
					<form action="/cart/store" method="POST">
						<?php echo csrf_field(); ?>
						<input type="hidden" value="<?php echo e($produk->id); ?>" name="id_produk">
						<button class="text-blue" style="width: 150px; padding-right: 41px; margin-top:20px;" type="submit">add to cart</button>
					</form>
					
				</div>
			</div>
			<div class="clearfix"> </div>
		
		</div>
		<div class="clearfix"> </div>
		<div class="row shop-item-info">
			<div class="col-xs-12">
					
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" role="tablist">
							<li role="presentation">
									<a class="text-uppercase">Review Product
									</a>
							</li>
					</ul>

					<!-- Tab panes -->
					<div class="tab-content">
							<div role="tabpanel" class="comments" id="comments">
									
									<!-- Header -->
									<h3 class="header"></h3>

									<!-- Comments -->
									<ul class="media-list">

											<!-- 1 comments -->
											<?php $__currentLoopData = $produk->reviewproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li class="media">
													<div class="media-left">
															<a href="#">
																	<img class="media-object" src="<?php echo e($review->user->image); ?>" alt="..." width="70px" height="70px">
															</a>
													</div>
													<div class="media-body">
															<h3 class="media-heading" style="font-weight: bold">
																	<a><?php echo e($review->user->name); ?></a>
															</h3>
															<h4>
																<?php echo e($review->content); ?>

															</h4>

															<div><span class="media-info" style="font-size: 12px; margin-top: 10px"><?php echo e(date("d F Y", strtotime($review->created_at))); ?></span></div>

															
															<?php $__currentLoopData = $review->response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respon_admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<div class="media">
																	<div class="media-left">
																			<a href="#">
																					<img class="media-object" src="<?php echo e($respon_admin->admin->image); ?>" alt="...">
																			</a>
																	</div>
																	<div class="media-body">
																			<h4 class="media-heading">
																					<a href="#"><?php echo e($respon_admin->admin->name); ?></a>
																			</h4>
																			<?php echo e($respon_admin->content); ?>


																			<span class="media-info"><?php echo e(date("d F Y", strtotime($respon_admin->created_at))); ?></span>

																	</div>
															</div>
																	
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

													</div>
											</li>
													
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</ul>

							
							</div>
					</div>
			</div>
	</div>
	<!-- END: COMMENTS -->
</div>
	</div>
</div>
<!-- //single -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_layouts.user_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_tampil.blade.php ENDPATH**/ ?>