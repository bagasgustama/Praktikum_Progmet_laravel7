
<?php $__env->startSection('content'); ?>

<style>.new-collections-grid1:nth-child(2){margin-top: 0px;}</style>
<!-- 
SLIDESHOW
=============================================== -->
<!-- breadcrumbs -->
<div class="breadcrumbs">
    <div class="container">
        <ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
            <li><a href="/home"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
            <li class="active">Products</li>
        </ol>
    </div>
</div>


<div class="products">
    <div class="container">
        <div class="col-md-4 products-left">
          <?php echo $__env->make('user_layouts.user_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-8 products-right">
            
            <div class="products-right-grids-bottom">
              <?php $__currentLoopData = $data_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produkrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="row">
                
                <?php $__currentLoopData = $produkrow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="new-collections-grid1 col-md-4 animated wow slideInUp" data-wow-delay=".5s">
                      <div class="new-collections-grid1-image">
                          
                          <a href="/produk/<?php echo e($produk["id"]); ?>/view" class="product-image"><img src="images/19.jpg" alt=" " class="img-responsive"></a>
                          <div class="new-collections-grid1-image-pos products-right-grids-pos">
                              
                          </div>
                      </div>
                      <h4><a href="/produk/<?php echo e($produk["id"]); ?>/view"><?php echo e($produk["product_name"]); ?></a></h4>
                      <p><?php echo e(Str::limit($produk["description"], 30, $end='...')); ?></p>
                      <div class="simpleCart_shelfItem products-right-grid1-add-cart">

                        <?php $__empty_1 = true; $__currentLoopData = $produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php if(date('Y-m-d')>= $diskonbarang->start && date('Y-m-d')< $diskonbarang->end): ?>
                            <?php
                            $nilaidiskon = ($diskonbarang->percentage / 100)* $produk->price
                            ?>
                            <div class="rating1">
                              <span class="starRating" style="height: 23px">

                                <?php if($produk->reviewproduk->avg('rate')): ?>

                                  <?php for($i = 0; $i < 5; $i++): ?>
                                      <?php if(floor($produk->reviewproduk->avg('rate')) - $i >= 1): ?>
                                      <img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
                                      <?php elseif($produk->reviewproduk->avg('rate') - $i > 0): ?>
                                      <img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
                                      <?php else: ?>
                                      <img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >
                                      <?php endif; ?>
                                  <?php endfor; ?>
                                <?php else: ?>
                                  <?php for($i = 0; $i < 5; $i++): ?>
                                  <img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >

                                  <?php endfor; ?>

                                <?php endif; ?>
                              </span>
                            </div>

                            <p><i>Rp.<?php echo e(number_format($produk["price"])); ?></i><span class=""><?php echo e($diskonbarang["percentage"]); ?>%</span><span class="item_price" style="font-weight: bold">Rp.<?php echo e(number_format($produk["price"]-$nilaidiskon)); ?></span><a class="item_add" style="backgroud-color:red; color:red;" href="/produk/<?php echo e($produk["id"]); ?>/view">View Product</a></p>

                        <?php else: ?>
                        <div class="rating1">
                          <span class="starRating" style="height: 23px">
                
                            <?php if($produk->reviewproduk->avg('rate')): ?>
                        
                              <?php for($i = 0; $i < 5; $i++): ?>
                                  <?php if(floor($produk->reviewproduk->avg('rate')) - $i >= 1): ?>
                                  <img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
                                  <?php elseif($produk->reviewproduk->avg('rate') - $i > 0): ?>
                                  <img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
                                  <?php else: ?>
                                  <img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >
                                  <?php endif; ?>
                              <?php endfor; ?>
                
                            <?php else: ?>
                              <?php for($i = 0; $i < 5; $i++): ?>
                              <img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >
                
                              <?php endfor; ?>
                
                            <?php endif; ?>
                          </span>
                        </div>
                            <p><span class="item_price" style="font-weight: bold">Rp.<?php echo e(number_format($produk["price"])); ?></span><a class="item_add" style="backgroud-color:red; color:red;" href="/produk/<?php echo e($produk["id"]); ?>/view">View Product</a></p>

                        <?php endif; ?>

                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="rating1">
                      <span class="starRating" style="height: 23px">
            
                        <?php if($produk->reviewproduk->avg('rate')): ?>
                    
                          <?php for($i = 0; $i < 5; $i++): ?>
                              <?php if(floor($produk->reviewproduk->avg('rate')) - $i >= 1): ?>
                              <img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
                              <?php elseif($produk->reviewproduk->avg('rate') - $i > 0): ?>
                              <img src="<?php echo e(asset('images/2.png')); ?>" data-imagezoom="true" >
                              <?php else: ?>
                              <img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >
                              <?php endif; ?>
                          <?php endfor; ?>
            
                        <?php else: ?>
                          <?php for($i = 0; $i < 5; $i++): ?>
                          <img src="<?php echo e(asset('images/1.png')); ?>" data-imagezoom="true" >
            
                          <?php endfor; ?>
            
                        <?php endif; ?>
                      </span>
                    </div>
                        <p><span class="item_price" style="font-weight: bold">Rp.<?php echo e(number_format($produk["price"])); ?></span><a class="item_add" style="backgroud-color:red; color:red;" href="/produk/<?php echo e($produk["id"]); ?>/view">View Product</a></p>

                    <?php endif; ?>

                          
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                <div class="clearfix"> </div>
            </div>
            
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<!-- //breadcrumbs -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_layouts.user_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_product.blade.php ENDPATH**/ ?>