
<?php $__env->startSection('content'); ?>

<!-- breadcrumbs -->
<div class="breadcrumbs">
  <div class="container">
    <ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
      <li><a href="/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
      <li class="active">Cart Page</li>
    </ol>
  </div>
</div>
<!-- //breadcrumbs -->
<!-- checkout -->
<div class="checkout">
  <div class="container">
    <h3 class="animated wow slideInLeft" data-wow-delay=".5s">Your shopping cart contains: <span><?php echo e($data_cart->count()); ?> Product</span></h3>
    <div class="checkout-right animated wow slideInUp" data-wow-delay=".5s">
      
      <?php if($data_cart->count()==0): ?>
      <!-- List body -->              
      <!-- Item -->
      
        <h2 class="text-uppercase text-blue" style="font-weight: bolder">
          Tidak Terdapat Barang di dalam Cart
        </h2>
          
      <?php else: ?>
      <table class="timetable_sub">
        <thead>
          <tr>
            <th>Product</th>
            <th>Quality</th>
            <th>Product Name</th>
            <th>Price/Qty</th>
            <th>Total Price</th>
            <th>Remove</th>
          </tr>
        </thead>

      <?php $__currentLoopData = $data_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="rem1">
          <td class="invert-image"><a href="single.html"><img src="images/22.jpg" alt=" " class="img-responsive" /></a></td>
          <td class="invert">
            <div class="quantity"> 
              <div class="quantity-select">           
                
                <div id="dec<?php echo e($cart->id); ?>" class=" entry value-minus">
                  <span type="button" onclick="minusQty('<?php echo e($cart->id); ?>')">
                      <i class="icofont icofont-caret-down"></i>
                  </span>
                </div>
                
                <?php $__empty_1 = true; $__currentLoopData = $cart->produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <input type="text" class="incdec input-qty input-text"
                name="qty[]" id="qty<?php echo e($cart->id); ?>" value="<?php echo e($cart->qty); ?>"/>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
                <input type="text" class="incdec input-qty input-text"
                name="qty[]" id="qty<?php echo e($cart->id); ?>" value="<?php echo e($cart->qty); ?>"/>
                
                <?php endif; ?>
                
                <div id="inc<?php echo e($cart->id); ?>" class=" entry value-plus active">
                  <span type="button" onclick="addQty('<?php echo e($cart->id); ?>')">
                      <i class="icofont icofont-caret-up"></i>
                  </span>
                </div>

                
              </div>
            </div>
          </td>
          <td class="invert"><?php echo e($cart->produk->product_name); ?></td>
          <td class="invert">
            
            <?php $__currentLoopData = $cart->produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(date('Y-m-d')>= $diskonbarang->start && date('Y-m-d')< $diskonbarang->end): ?>
                
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
        <?php $__empty_1 = true; $__currentLoopData = $cart->produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  
        <?php
            $nilaidiskon = ($diskonbarang->percentage / 100)* $cart->produk->price
        ?>
  
        <?php if(date('Y-m-d')>= $diskonbarang->start && date('Y-m-d')< $diskonbarang->end): ?>
            <span class="price">
                <span class="prc" >
                    <i>Rp.</i>
                    <span name="price"><?php echo e(number_format($cart->produk->price-$nilaidiskon)); ?></span>
                </span>
            </span>
  
            
            
        <?php else: ?>
            <!-- Currency -->
            <span class="price">
                <span class="prc" >
                    <i>Rp.</i>
                    <span name="price"><?php echo e(number_format($cart->produk->price)); ?></span>
                </span>
            </span>
            
        <?php endif; ?>
    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
        <!-- Currency -->
        <span class="price">
            <span class="prc" >
                <i>Rp.</i>
                <span name="price"><?php echo e(number_format($cart->produk->price)); ?></span>
            </span>
        </span>
  
        <?php endif; ?>
          </td>
          <td class="invert">
            <?php $__empty_1 = true; $__currentLoopData = $cart->produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if(date('Y-m-d')>= $diskonbarang->start && date('Y-m-d')< $diskonbarang->end): ?>
                  <i>Rp.</i>
                  <span id="hargadiskon<?php echo e($cart->id); ?>" class="total">
                      <?php echo e(number_format(($cart->produk->price-$nilaidiskon)*$cart->qty)); ?>

                  </span>
                  
              <?php else: ?>
                  <i>Rp.</i>
                  <span id="hargadiskon<?php echo e($cart->id); ?>" class="total">
                      <?php echo e(number_format(($cart->produk->price)*$cart->qty)); ?>

                  </span>
                  
              <?php endif; ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              
                  <i>Rp.</i>
                  <span id="harga<?php echo e($cart->id); ?>" name="price" class="total">
                      <?php echo e(number_format(($cart->produk->price)*$cart->qty)); ?>

                  </span>

              <?php endif; ?>

          </td>
          <td class="invert">
            
            <div class="rem">
              <div class="close1"> 
                
                <form action="/produk/cart/<?php echo e($cart->id); ?>/deletecart" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger" onclick="return confirm('Anda yakin ingin hapus data ini?')">X
                          <i class="icofont icofont-close-line"></i>
                      </button>
              </form>

              </div>
            </div>
            
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!--quantity-->
            <script>
            $('.value-plus').on('click', function(){
              var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)+1;
              divUpd.text(newVal);
            });

            $('.value-minus').on('click', function(){
              var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)-1;
              if(newVal>=1) divUpd.text(newVal);
            });
            </script>
          <!--quantity-->
      </table>
      <div style="margin-top: 30px" class="checkout-left-basket animated wow slideInLeft" data-wow-delay=".5s">
        
        <a href="/checkout"><h4>Continue to checkout</h4></a>
        
        
      </div>
      <?php endif; ?>
    </div>
    <div class="checkout-left">	
      <div class="checkout-right-basket animated wow slideInRight" data-wow-delay=".5s">
        <a href="/produk"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Continue Shopping</a>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
</div>
<!-- //checkout -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-script'); ?>
<script>
    jQuery(document).ready(function() {       
        jQuery.ajaxSetup({        
            headers: {            
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')        
            }    
        });    
    });

    function formatRupiah(angka, prefix){
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split   		= number_string.split(','),
        sisa     		= split[0].length % 3,
        rupiah     		= split[0].substr(0, sisa),
        ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if(ribuan){
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    incrementVar = 0;

    $('.inc.button').click(function(){
        var cart_id = $(this).attr('id').substring(3);
        // console.log(cart_id);
        var max = $(this).data("max");
            var $this = $(this),
            $input = $this.next('input'),
            $parent = $input.closest('div'),
            newValue = parseInt($input.val())+1;
        $parent.find('.inc').addClass('a'+newValue);
        $input.val(newValue);
        price = $(this).next('input').data('price'); 
        incrementVar += newValue;
        total = price * newValue;
        console.log(newValue);
        $(`#hargadiskon${cart_id}`).html(formatRupiah(total.toString()));
        $(`#harga${cart_id}`).html(formatRupiah(total.toString()));
    });

    $('.dec.button').click(function(){
        var cart_id = $(this).attr('id').substring(3);
        // console.log(cart_id);

        var min = $(this).data("min");
            var $this = $(this),
            $input = $this.prev('input'),
            $parent = $input.closest('div'),
            newValue = parseInt($input.val());
        $parent.find('.dec').addClass('a'-newValue);

        if (newValue <= 1) {
            price = $(this).prev('input').data('price');
            total = price * 1;
            console.log(price);

            $(`#hargadiskon${cart_id}`).html(formatRupiah(price.toString()));
            $(`#harga${cart_id}`).html(formatRupiah(price.toString()));
        } else {
            $input.val(newValue-1);
            price = $(this).prev('input').data('price');
            total = price * (newValue-1);

            $(`#hargadiskon${cart_id}`).html(formatRupiah(total.toString()));
            $(`#harga${cart_id}`).html(formatRupiah(total.toString()));
        }

        // console.log(newValue);
    });
    //newValue merupakan variabel quantity barang\

    function addQty(id){
        var url = '/produk/addqty/'+id;
        $.ajax({
            url:url,
            method : 'POST',
            success: function(response) {
                if(response.status == 0){
                    alert('Stock barang habis');
                }else{
                    $('#qty'+id).val(response.qty);
                    $('#hargadiskon'+id).html(response.nilaidiskon);
                    $('#harga'+id).html(response.nilaidiskon);
                }
            }
        })
    }

    function minusQty(id){
        var url = '/produk/minusqty/'+id;
        $.ajax({
            url:url,
            method : 'POST',
            success: function(response) {
                if(response.status == 0){
                    alert('Kuantitas barang tidak boleh 0');
                }else{
                    $('#qty'+id).val(response.qty);
                    $('#hargadiskon'+id).html(response.nilaidiskon);
                    $('#harga'+id).html(response.nilaidiskon);
                }
            }
        })
    }

</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_layouts.user_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_cart.blade.php ENDPATH**/ ?>