
<?php $__env->startSection('content'); ?>
<!-- <!-- breadcrumbs -->
<div class="breadcrumbs">
  <div class="container">
    <ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
      <li><a href="/"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
      <li class="active">Checkout Page</li>
    </ol>
  </div>
</div>
<!-- //breadcrumbs -->
<!-- checkout -->
<div class="checkout">
  <div class="container">
    
    <h1 class="header text-uppercase">
      Recepient Address 

  </h1>
    <div class="checkout-right animated wow slideInUp" data-wow-delay=".5s">
      <form action="/checkout-produk" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label" style="padding: 0px; margin-top :20px;">Address</label>
            <input type="text" class="form-control" id="alamat_user" name="address" aria-describedby="emailHelp" required>
        </div>
        <div class="mb-3 form-check">
            <label class="form-check-label" for="exampleCheck1" style="padding: 0px; margin-top :20px;">Province</label>
        </div>
        <select class=" form-control" style="padding: 0px " aria-label="Default select example" id="provinsi_user" name="province">
            <option selected disabled>--PILIH--</option>
            <?php $__currentLoopData = $data_provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar_provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option data-provinsi="<?php echo e($daftar_provinsi->province_id); ?>" value="<?php echo e($daftar_provinsi->name); ?>"><?php echo e($daftar_provinsi->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="mb-3 form-check">
            <label class="form-check-label" for="exampleCheck1" style="padding: 0px; margin-top :20px;">City</label>
        </div>
        <select class=" form-control" style="padding: 0px " aria-label="Default select example" id="kota_user" name="regency">
            <option selected disabled>--PILIH--</option>
            <?php $__currentLoopData = $data_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar_kota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option data-kota="<?php echo e($daftar_kota->city_id); ?>" value="<?php echo e($daftar_kota->name); ?>"><?php echo e($daftar_kota->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="mb-3 form-check">
            <label class="form-check-label" for="exampleCheck1" style="padding: 0px; margin-top :20px;">Courier</label>
        </div>
        <select class=" form-control" style="padding: 0px margin-bottom :20px;" aria-label="Default select example" id="pilihan_kurir" name="courier_id">
            <option selected>--PILIH--</option>
            <?php $__currentLoopData = $data_kurir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar_kurir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option data-kurir="<?php echo e($daftar_kurir->code); ?>" value="<?php echo e($daftar_kurir->id); ?>"><?php echo e($daftar_kurir->courier); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="mb-3 form-check">
          <label class="form-check-label" for="exampleCheck1" style="padding: 0px; margin-top :20px;">Layanan</label>
        </div>
        
        <select class=" form-control" style="padding: 0px " name="shipping_cost" id="layanan" required>
          <option value="" selected disabled>Pilih Layanan</option>
      </select>
        <button type="submit" class="btn btn-primary " style="margin-top :20px;">Submit</button>
        
        
      
    </div>
    <div class="checkout-left">	
      <div class="checkout-left-basket animated wow slideInLeft" data-wow-delay=".5s">
        <h4>List Order</h4>
        <ul class="list-2">
          
      </ul>
        <ul>
          <li>Total <i>-</i> <span>Rp.<?php echo e(number_format($total)); ?> </span></li>
          <li>Total Weight <i>-</i> <span id="berat_total" data-berat="<?php echo e($berat_total); ?>" class="sub">
            <?php echo e(number_format($berat_total)); ?> gram
        </span>
          
          
        </ul>
      </div>
      
      <div class="clearfix"> </div>
    </div>
    <table class="table product-table">
        <!-- Table head -->
        <thead>

            <tr>

                <th></th>

                <th class="font-weight-bold">
                <strong>Product</strong>
                </th>

                <th class="font-weight-bold">
                <strong>Price</strong>
                </th>

                <th class="font-weight-bold text-center">
                <strong>QTY</strong>
                </th>  

            </tr>

        </thead>
        <!-- Table head -->

        <!-- Table body -->
        <tbody>
        <?php $__currentLoopData = $data_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <?php
                $image = $cart->produk->getfirstimage();
            ?>
            <th scope="row">
            
                
            </th>

            <td>
                <h5 class="mt-3">
                    <strong><?php echo e($cart->produk->product_name); ?></strong>
                </h5>
            </td>

            <?php $__empty_1 = true; $__currentLoopData = $cart->produk->diskon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskonbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php
            $nilaidiskon = ($diskonbarang->percentage / 100)* $cart->produk->price
            ?>

            <?php if(date('Y-m-d')>= $diskonbarang->start && date('Y-m-d')< $diskonbarang->end): ?>
                <td>Rp
                    <span class="float-lef grey-text price0">
                        <?php echo e(number_format(($cart->produk->price-$nilaidiskon)*$cart->qty)); ?>

                    </span>
                    <input type="hidden" name="discount[]" value="<?php echo e($diskonbarang->percentage); ?>">
                    <input type="hidden" name="selling_price[]" value="<?php echo e(($cart->produk->price-$nilaidiskon)*$cart->qty ?? '0'); ?>">
                </td>
                
            <?php else: ?>
                <td>Rp
                    <span class="float-lef grey-text price0">
                        <?php echo e(number_format(($cart->produk->price)*$cart->qty)); ?>

                    </span>
                    <input type="hidden" name="discount[]" value="0">
                    <input type="hidden" name="selling_price[]" value="<?php echo e(($cart->produk->price)*$cart->qty ?? '0'); ?>">
                </td>
            <?php endif; ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <td>Rp
                <span class="float-lef grey-text price0">
                    <?php echo e(number_format(($cart->produk->price)*$cart->qty)); ?>

                </span>
                <input type="hidden" name="discount[]" value="0">
                <input type="hidden" name="selling_price[]" value="<?php echo e(($cart->produk->price)*$cart->qty ?? '0'); ?>">
            </td>

            <?php endif; ?>

            <td class="text-center text-md-left">
                <p class="text-danger" style="display:none" id="notif0"></p>
                <span class="qty0"><?php echo e(number_format($cart->qty)); ?></span>
            </td>    
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <!-- Table body -->
</table>
  </form>
  <?php $__currentLoopData = $data_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/produk/cart/<?php echo e($cart->id); ?>/deletecart" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Anda yakin ingin hapus data ini?')">Cancel Transaction
                    <i class="icofont icofont-close-line"></i>
                </button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>


</div>
<!-- //checkout -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('after-script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<script>
    jQuery(document).ready(function() {       
        jQuery.ajaxSetup({        
            headers: {            
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')        
            }    
        });    
    });

    $('#pilihan_kurir').on('change', function() {
        
        var kurir =$('#pilihan_kurir').find('option:selected').data("kurir");
        var kota = $('#kota_user').find('option:selected').data("kota");
        var berat = $('#berat_total').data('berat');
        var html_option = '';
        console.log(kurir);
        console.log(kota);
        console.log(berat);
        $.ajax({
            url: '/produk/cekongkir',
            type: 'post',
            data: {
                kurir: kurir,
                kota: kota,
                berat: berat
                },
            success:function(data){
                $('select[name="shipping_cost"]').html('<option value="" selected>Tidak ada layanan</option>');
            
                // looping data result nya
                $.each(data, function(key, value){
                    // looping data layanan misal jne reg, jne oke, jne yes
                    $.each(value.costs, function(key1, value1){
                        // untuk looping cost nya masing masing
                        $.each(value1.cost, function(key2, value2){
                            html_option +='<option value="'+ value2.value +'">' + value1.service + '-' + value1.description + '- Rp.' +value2.value+ '</option>';
                            $('select[name="shipping_cost"]').html( html_option);
                        });

                        loadSubOngkir();
                        loadtotals();
                    });
                });
            }
        });
    });

    

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_layouts.user_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_checkoutnow.blade.php ENDPATH**/ ?>