<!-- 
        NAVBAR
        =============================================== -->
        <nav class="navbar navbar-default">
            
          <div class="container">
             
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="#">
                      <img src="<?php echo e(asset('pengguna/html/images/main-brand.png')); ?>" alt="" class="brand">
                  </a>
              </div>

              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  
                  <!-- Top panel / search / phone -->
                  <div class="top-panel">
                     
                      <div class="phone text-blue">
                          <i class="icofont icofont-phone-circle"></i>
                          +62 85 536 553 596
                      </div>
                      
                      
                      
                      <ul class="list-btn-group navbar-right">
                          <li class="nav-item dropdown">
                              <a id="navbarDropdown" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>

                                  <?php if(Auth::check()): ?>
                                      <?php echo e(Auth::user()->name); ?>

                                  <?php else: ?>
                                      Guest
                                  <?php endif; ?>

                              </a>

                              
                              <?php if(Auth::check()): ?>
                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                     onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">
                                      <?php echo e(__('Logout')); ?>

                                  </a>

                                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                      <?php echo csrf_field(); ?>
                                  </form>
                              </div>
                              <?php else: ?>
                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="/login">
                                      Login
                                  </a>

                                  
                              </div>
                              <?php endif; ?>
                          </li>
                      </ul>
                  </div>
                  
                  <ul class="nav navbar-nav navbar-right info-panel">

                      <?php if(Auth::check()): ?>
                      
                      <!-- Nav Item - Notifikasi -->
                      
                      

                          

                              
                              
                              <!-- Counter - Alerts -->
                              
                              
                                  
                              
                                  
                              

                              
                              

                              
                                  
                      

                      <!-- Nav Item - Pesan -->
                      
                      <?php else: ?>

                      <?php endif; ?>

                      <!-- Profile -->
                      <li class="profile">
                          <span class="wrap">
                              
                              <!-- Image -->
                              <span class="image bg-white">
                                  
                                  <!-- New message badge -->
                                  
                                 
                                  <span class="icon">
                                      <i class="icofont icofont-user-alt-4 text-blue"></i>
                                  </span>

                              </span>
                              
                              <!-- Info -->
                              <span class="info">
                                  <!-- Name -->
                                  <?php if(Auth::check()): ?>
                                      <span class="name text-uppercase"><?php echo e(Auth::user()->name); ?></span>
                                      <a href="/profile">see profile</a>
                                  <?php else: ?>
                                      <span class="name text-uppercase">Guest</span>
                                      <a href="/login">Login</a>
                                  <?php endif; ?>
                                  
                              </span>
                          </span>
                      </li>
                      
                      <!-- Cart -->
                      <li class="cart">

                          <?php if(Auth::check()): ?>
                              <li class="more-btn sdw ">
                                  <a href="/produk/cart" class="btn btn-primary">
                                      Shopping cart 
                                      <i class="icofont icofont-cart-alt"></i>
                                  </a>
                              </li>
                          <?php else: ?>

                          <?php endif; ?>
                          
                      </li>
                  </ul>
                  <ul class="nav navbar-nav">
                      <li class="<?php echo e(request()->is('welcome','/') ? 'active' : ''); ?>">
                          <a href="/welcome">
                              home
                          </a>
                      </li>
                      <li class="<?php echo e(request()->is('kategori') ? 'active' : ''); ?>">
                          <a href="/kategori">
                              product category
                          </a>
                      </li>
                      <li class="<?php echo e(request()->is('about') ? 'active' : ''); ?>">
                          <a href="/about">
                              about us
                          </a>
                      </li>
                  </ul>
              
              </div><!-- /.navbar-collapse -->
          </div><!-- /.container-fluid -->
      </nav>
      <!-- END: NAVBAR --><?php /**PATH C:\xampp\htdocs\Praktikum_prognet\resources\views/user_layouts/user_navbar.blade.php ENDPATH**/ ?>